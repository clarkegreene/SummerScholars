//
//  ViewController.swift
//  Clarke Greene - Mini Project 2
//
//  Created by SMART Scholars on 7/19/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

